# Netflix Profile API

## Live Deployment URL
https://netflix-profile-api.onrender.com

## Swagger Documentation URL
https://netflix-profile-api.onrender.com/api-docs

## GitHub Repository Link
https://github.com/rishirbagal-cyber/netflix-profile

## Required Environment Variables
PORT

## Local Setup Instructions
npm install
node server.js
